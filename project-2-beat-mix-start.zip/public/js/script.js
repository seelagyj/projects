// Drum Arrays
let kicks
let snares
let hiHats
let rideCymbals

